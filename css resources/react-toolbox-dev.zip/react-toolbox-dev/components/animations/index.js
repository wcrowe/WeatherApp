export SlideLeft from './slide-left.scss';
export SlideRight from './slide-right.scss';
export ZoomIn from './zoom-in.scss';
export ZoomOut from './zoom-out.scss';
