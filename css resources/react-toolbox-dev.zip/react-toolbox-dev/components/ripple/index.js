import rippleFactory from './Ripple.js';
import theme from './theme.scss';

export default (options) => rippleFactory({ ...options, theme });
