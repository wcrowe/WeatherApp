import 'core-js/fn/array/from';
import 'core-js/fn/array/iterator';
import 'core-js/fn/array/find-index';
import 'core-js/fn/map';
import 'core-js/fn/string/starts-with';
import 'core-js/fn/string/includes';
import 'core-js/fn/symbol';
