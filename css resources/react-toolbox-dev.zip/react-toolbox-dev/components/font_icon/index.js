import FontIcon from './FontIcon.js';

export default FontIcon;
export { FontIcon };
