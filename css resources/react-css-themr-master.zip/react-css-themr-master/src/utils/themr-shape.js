import { PropTypes } from 'react'

export default PropTypes.shape({
  theme: PropTypes.object.isRequired
})
