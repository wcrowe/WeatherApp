module.exports = {
	selectArrows: require('./selectArrows')
};
