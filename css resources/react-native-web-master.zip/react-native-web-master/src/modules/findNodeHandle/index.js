import ReactDOM from 'react-dom';
const findNodeHandle = ReactDOM.findDOMNode;
export default findNodeHandle;
