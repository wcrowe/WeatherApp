/* eslint-env mocha */

suite('components/ActivityIndicator', () => {
  test.skip('NO TEST COVERAGE', () => {});
});
