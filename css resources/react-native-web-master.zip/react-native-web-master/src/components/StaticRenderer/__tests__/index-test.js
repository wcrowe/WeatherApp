/* eslint-env mocha */

suite('components/StaticRenderer', () => {
  test.skip('NO TEST COVERAGE', () => {});
});
