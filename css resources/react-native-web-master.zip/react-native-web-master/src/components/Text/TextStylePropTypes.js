import TextPropTypes from '../../propTypes/TextPropTypes';
import ViewStylePropTypes from '../View/ViewStylePropTypes';

module.exports = {
  ...ViewStylePropTypes,
  ...TextPropTypes
};
