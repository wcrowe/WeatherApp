/* eslint-env mocha */

suite('components/ScrollView', () => {
  test('NO TEST COVERAGE');
});
