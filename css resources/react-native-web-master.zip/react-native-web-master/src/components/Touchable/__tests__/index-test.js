/* eslint-env mocha */

suite('components/Touchable', () => {
  test.skip('NO TEST COVERAGE', () => {});
});
