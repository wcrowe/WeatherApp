/* eslint-env mocha */

suite('components/ListView', () => {
  test('NO TEST COVERAGE');
});
