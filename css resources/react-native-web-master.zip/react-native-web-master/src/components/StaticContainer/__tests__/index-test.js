/* eslint-env mocha */

suite('components/StaticContainer', () => {
  test.skip('NO TEST COVERAGE', () => {});
});
