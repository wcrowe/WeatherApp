/* eslint-env mocha */

suite('apis/NetInfo', () => {
  test.skip('NO TEST COVERAGE', () => {});
});
