const Platform = {
  OS: 'web',
  select: (obj: Object) => obj.web
};

module.exports = Platform;
