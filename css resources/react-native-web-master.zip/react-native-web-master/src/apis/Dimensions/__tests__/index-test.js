/* eslint-env mocha */

suite('apis/Dimensions', () => {
  test.skip('NO TEST COVERAGE', () => {});
});
