/* eslint-env mocha */

suite('apis/PixelRatio', () => {
  test.skip('NO TEST COVERAGE', () => {});
});
