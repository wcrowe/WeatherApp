<!--
React Native for Web is an implementation of React Native. If you have feature
requests, you should post them to https://productpains.com/product/react-native/.

GitHub issues should only be used for bugs or Web-specific features you believe
React Native requires.

Make sure to add ALL the information needed to understand the bug so that
someone can help. If the info is missing we'll add the 'needs more information'
label and close the issue until there is enough information.
-->

**What is the current behavior?**

Link to minimal test case: (template: [codepen](https://codepen.io/necolas/pen/PZzwBR?editors=0010))

**What is the expected behaviour?**

**Steps to reproduce**

1.
2.

**Environment (include versions)**

OS:
Device:
Browser:
React Native for Web (version):
React (version):
