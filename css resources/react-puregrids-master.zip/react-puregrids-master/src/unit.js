'use strict';


import React from 'react';
import classnames from 'classnames';

import unitsizes from './unitsizes';

/**
 *  This wraps a DOM element of choice with Pure unit classes.
 */
export default class Unit extends React.Component {
  static defaultProps = {
    element: 'div',
    u: '1'
  }

  static propTypes = {
    u: React.PropTypes.string.isRequired,
    sm: React.PropTypes.oneOf(unitsizes),
    md: React.PropTypes.oneOf(unitsizes),
    lg: React.PropTypes.oneOf(unitsizes),
    xl: React.PropTypes.oneOf(unitsizes),
    className: React.PropTypes.string
  }

  getClasses = () => {
    if (propsHasMediaQueryClasses(this.props) && this.props.className) {
      return {className: this.props.className};
    } else {
      return {
        className: classnames(
          `pure-u-${this.props.u}`,
          this.props.className
        )
      };
    }
  }

  pureClasses = () => {
    let classes = {};
    classes[`pure-u-sm-${this.props.sm}`] = this.props.sm;
    classes[`pure-u-md-${this.props.md}`] = this.props.md;
    classes[`pure-u-lg-${this.props.lg}`] = this.props.lg;
    classes[`pure-u-xl-${this.props.xl}`] = this.props.xl;

    return classes;
  }

  renderChildren = () => {
    let children = [];

    React.Children.forEach(this.props.children, (child) => {
      children.push(React.cloneElement(child, {
        className: classnames(this.pureClasses())
      }));
    });

    return children;
  }

  render() {
    return React.DOM[this.props.element](this.getClasses(), this.renderChildren())
  }
}

function propsHasMediaQueryClasses(props) {
  return ['sm', 'md', 'lg', 'xl'].some((prop) => { return prop in props; });
}

