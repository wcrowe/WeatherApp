'use strict';


import React from 'react';
import classnames from 'classnames';


/**
 *  This class creates a new DOM element of choice
 *  with the pure-g class and other classes appended to it.
 *
 *  This will wrap any Unit components.
 *
 */
export default class Grid extends React.Component {
  static defaultProps = {
    element: 'div'
  }

  getClasses = () => {
    return classnames('pure-g', this.props.className);
  }

  render() {
    return React.DOM[this.props.element]({className: this.getClasses()}, this.props.children);
  }
}
