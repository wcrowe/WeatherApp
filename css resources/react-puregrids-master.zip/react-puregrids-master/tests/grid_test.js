'use strict';

import expect from 'expect.js';
import React from 'react/addons';

import {Grid} from '../src/index';


let TestUtils = React.addons.TestUtils;

describe('Grid', () => {
  const shallowRenderer = TestUtils.createRenderer();

  it('renders as a DIV default', () => {
    shallowRenderer.render(React.createElement(Grid, {}, ''));
    const component = shallowRenderer.getRenderOutput();

    expect(component.type).to.be('div');
  });

  it('renders as any given DOM element', () => {
    shallowRenderer.render(React.createElement(Grid, {element: 'header'}, ''));
    const component = shallowRenderer.getRenderOutput();

    expect(component.type).to.be('header');
  });

  it('renders with only pure-g as classname given no classname props', () => {
    shallowRenderer.render(React.createElement(Grid, {}, ''));
    const component = shallowRenderer.getRenderOutput();

    expect(component.props.className).to.be('pure-g');
  });

  it('renders with pure-g and classname prop', () => {
    shallowRenderer.render(React.createElement(Grid, {className: 'berry'}, ''));
    const component = shallowRenderer.getRenderOutput();

    expect(component.props.className).to.be('pure-g berry');
  });
});
