'use strict';

import expect from 'expect.js';
import React from 'react/addons';

import {Grid, Unit} from '../src/index';


let TestUtils = React.addons.TestUtils;


describe('Composed Grid and Unit', () => {
  const shallowRenderer = TestUtils.createRenderer();

  it('renders a proper grid structure', () => {
    const child = React.createElement(Unit, {}, '');
    shallowRenderer.render(React.createElement(Grid, {}, React.createElement(Unit, {}, '')));
    const component = shallowRenderer.getRenderOutput();

    expect(component.type).to.be('div');
    expect(component.props.children).to.eql(child);
  });

  it('grid and unit keeps children', () => {
    const child = React.DOM.p(null, 'Hello');

    shallowRenderer.render(React.createElement(Grid, {}, React.createElement(Unit, {}, child)));
    const component = shallowRenderer.getRenderOutput();

    let unit = component.props.children;

    expect(unit.props.children).to.eql(child);
  });
});
