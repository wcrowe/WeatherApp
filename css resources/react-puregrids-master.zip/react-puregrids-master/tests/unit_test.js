'use strict';

import expect from 'expect.js';
import React from 'react/addons';

import {Unit} from '../src/index';


let TestUtils = React.addons.TestUtils;

describe('Unit', () => {
  const shallowRenderer = TestUtils.createRenderer();
  const child = React.DOM.p({key: 1}, '');

  it('renders as a DIV default', () => {
    let component;
    shallowRenderer.render(React.createElement(Unit, {}, child));
    component = shallowRenderer.getRenderOutput();

    expect(component.type).to.be('div');
  });

  it('renders as any given tag', () => {
    let component;
    shallowRenderer.render(React.createElement(Unit, {element: 'header'}, child));
    component = shallowRenderer.getRenderOutput();

    expect(component.type).to.be('header');
  });

  it('renders with a given classname prop', () => {
    let component;
    shallowRenderer.render(React.createElement(Unit, {className: 'barry'}, child));
    component = shallowRenderer.getRenderOutput();

    expect(component.props.className).to.be('pure-u-1 barry');
  });


  describe('render with responsive classes', () => {
    const children = [
      React.DOM.p({key: 1}, 'hello'),
      React.DOM.p({key: 2}, 'world'),
      React.DOM.p({key: 3}, 'we meet again')
    ];
    let component;
    let child;

    it('adds a responsive classes to children', () => {
      shallowRenderer.render(React.createElement(Unit, {sm: '1-1'}, children));

      component = shallowRenderer.getRenderOutput();
      child = component.props.children[0];

      expect(child.props.className).to.be('pure-u-sm-1-1');
    });

    it('adds some of the responsive classes', () => {
      shallowRenderer.render(React.createElement(Unit, {sm: '1-1', xl: '1-4'}, children));

      component = shallowRenderer.getRenderOutput();
      child = component.props.children[0];

      expect(child.props.className).to.be('pure-u-sm-1-1 pure-u-xl-1-4');
    });

    it('adds all of the responsive classes sm, md, lg, xl', () => {
      const classes = {
        sm: '1-1',
        md: '1-2',
        lg: '1-3',
        xl: '1-4'
      };

      shallowRenderer.render(React.createElement(Unit, classes, children));
      component = shallowRenderer.getRenderOutput();
      child = component.props.children[0];

      expect(child.props.className).to.be('pure-u-sm-1-1 pure-u-md-1-2 pure-u-lg-1-3 pure-u-xl-1-4');
    });
  });
});
